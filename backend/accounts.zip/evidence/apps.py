from django.apps import AppConfig


class EvidenceConfig(AppConfig):
    name = 'evidence'
