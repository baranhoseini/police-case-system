from django.apps import AppConfig


class SuspectsConfig(AppConfig):
    name = 'suspects'
