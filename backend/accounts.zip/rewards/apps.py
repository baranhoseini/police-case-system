from django.apps import AppConfig


class RewardsConfig(AppConfig):
    name = 'rewards'
